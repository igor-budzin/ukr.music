module.exports = {
	audioBacketName: 'cabin-of-pilot',
  audioCoverBacketName: 'cop-audio-covers',
	accessKeyId: 'AKIAIOJVJZJZFK5GC6QA',
	secretAccessKey: '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'
}