require('babel-register');
module.exports = require('./webpack.config.server.js');
