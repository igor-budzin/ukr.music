// Libraries
import React, { Component, Fragment } from 'react';

import RegisterContainer from 'universal/components/Auth/RegisterContainer';

export default class RegisterPage extends Component {
	render() {
		return (
			<div>
				<RegisterContainer />
			</div>
		);
	}
}
