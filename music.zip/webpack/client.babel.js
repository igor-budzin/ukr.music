require('babel-register');
module.exports = require('./webpack.config.client.js');
