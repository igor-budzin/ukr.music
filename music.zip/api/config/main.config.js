module.exports = {
  mongo_main_db: 'musicDB',
  mongo_main_user: "music-user",
  mongo_main_pass: "O9Sa54540XgsWkGb"
};