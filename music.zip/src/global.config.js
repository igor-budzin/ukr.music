const production = process.env.NODE_ENV === 'production';

export const globlaConfig = {
	protocol: 'http',
	host: production ? '31.131.30.233' : 'localhost',
	apiPrefix: 'api',
	apiPort: production ? '8000' : '8080'
};

export const API_URL = `${globlaConfig.protocol}://${globlaConfig.host}:${globlaConfig.apiPort}/${globlaConfig.apiPrefix}`;